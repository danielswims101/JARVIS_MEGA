// JARVIS orb engine — GPU particle system + post FX. Exposes window.JARVIS_ENGINE.
import * as THREE from 'https://unpkg.com/three@0.160.0/build/three.module.js';
import { EffectComposer } from 'https://unpkg.com/three@0.160.0/examples/jsm/postprocessing/EffectComposer.js';
import { RenderPass } from 'https://unpkg.com/three@0.160.0/examples/jsm/postprocessing/RenderPass.js';
import { UnrealBloomPass } from 'https://unpkg.com/three@0.160.0/examples/jsm/postprocessing/UnrealBloomPass.js';
import { ShaderPass } from 'https://unpkg.com/three@0.160.0/examples/jsm/postprocessing/ShaderPass.js';
import { OutputPass } from 'https://unpkg.com/three@0.160.0/examples/jsm/postprocessing/OutputPass.js';

const STATES = ['idle', 'listening', 'thinking', 'speaking', 'alert'];

/* ---------------------------------------------------------------- audio --- */
function makeAudio() {
  const api = {
    wave: new Uint8Array(1024).fill(128),
    fft: new Uint8Array(32),
    level: 0, live: false, ready: false, denied: false,
    t: 0,
    update(dt) {
      if (api.analyser) {
        api.analyser.getByteTimeDomainData(api.raw);
        api.analyser.getByteFrequencyData(api.rawF);
        for (let i = 0; i < 1024; i++) api.wave[i] = api.raw[i % api.raw.length];
        const step = Math.floor(api.rawF.length / 32);
        for (let i = 0; i < 32; i++) {
          let s = 0;
          for (let j = 0; j < step; j++) s += api.rawF[i * step + j];
          api.fft[i] = s / step;
        }
      } else {
        // synthetic breath — layered sines + drift so it never looks dead
        api.t += dt;
        const t = api.t;
        for (let i = 0; i < 1024; i++) {
          const x = i / 1024;
          const v =
            Math.sin(x * 34 + t * 2.1) * 0.42 * (0.55 + 0.45 * Math.sin(t * 0.63)) +
            Math.sin(x * 91 + t * 3.7) * 0.2 * (0.5 + 0.5 * Math.sin(t * 0.41 + 1.2)) +
            Math.sin(x * 7 - t * 1.1) * 0.26 +
            (Math.random() - 0.5) * 0.05;
          api.wave[i] = 128 + v * 52;
        }
        for (let i = 0; i < 32; i++) {
          const f = i / 32;
          const env = Math.pow(1 - f, 1.7);
          api.fft[i] = Math.max(0, Math.min(255,
            (env * 190) * (0.45 + 0.55 * Math.abs(Math.sin(t * (0.7 + f * 2.3) + i * 0.9)))
            + Math.random() * 14));
        }
      }
      let sum = 0;
      for (let i = 0; i < 1024; i += 4) sum += Math.abs(api.wave[i] - 128);
      api.level = Math.min(1, (sum / 256) / 46);
    },
    async start() {
      if (api.ready) return;
      api.ready = true;
      try {
        const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
        const ctx = new (window.AudioContext || window.webkitAudioContext)();
        const src = ctx.createMediaStreamSource(stream);
        const an = ctx.createAnalyser();
        an.fftSize = 2048; an.smoothingTimeConstant = 0.78;
        src.connect(an);
        api.ctx = ctx; api.analyser = an;
        api.raw = new Uint8Array(an.fftSize);
        api.rawF = new Uint8Array(an.frequencyBinCount);
        api.live = true;
      } catch (e) { api.denied = true; }
    }
  };
  return api;
}

/* --------------------------------------------------------------- shaders --- */
const NOISE = `
vec4 permute(vec4 x){return mod(((x*34.0)+1.0)*x,289.0);}
vec4 taylorInvSqrt(vec4 r){return 1.79284291400159-0.85373472095314*r;}
float snoise(vec3 v){
  const vec2 C=vec2(1.0/6.0,1.0/3.0); const vec4 D=vec4(0.0,0.5,1.0,2.0);
  vec3 i=floor(v+dot(v,C.yyy)); vec3 x0=v-i+dot(i,C.xxx);
  vec3 g=step(x0.yzx,x0.xyz); vec3 l=1.0-g; vec3 i1=min(g.xyz,l.zxy); vec3 i2=max(g.xyz,l.zxy);
  vec3 x1=x0-i1+1.0*C.xxx; vec3 x2=x0-i2+2.0*C.xxx; vec3 x3=x0-1.0+3.0*C.xxx;
  i=mod(i,289.0);
  vec4 p=permute(permute(permute(i.z+vec4(0.0,i1.z,i2.z,1.0))+i.y+vec4(0.0,i1.y,i2.y,1.0))+i.x+vec4(0.0,i1.x,i2.x,1.0));
  float n_=1.0/7.0; vec3 ns=n_*D.wyz-D.xzx;
  vec4 j=p-49.0*floor(p*ns.z*ns.z);
  vec4 x_=floor(j*ns.z); vec4 y_=floor(j-7.0*x_);
  vec4 x=x_*ns.x+ns.yyyy; vec4 y=y_*ns.x+ns.yyyy; vec4 h=1.0-abs(x)-abs(y);
  vec4 b0=vec4(x.xy,y.xy); vec4 b1=vec4(x.zw,y.zw);
  vec4 s0=floor(b0)*2.0+1.0; vec4 s1=floor(b1)*2.0+1.0; vec4 sh=-step(h,vec4(0.0));
  vec4 a0=b0.xzyw+s0.xzyw*sh.xxyy; vec4 a1=b1.xzyw+s1.xzyw*sh.zzww;
  vec3 p0=vec3(a0.xy,h.x); vec3 p1=vec3(a0.zw,h.y); vec3 p2=vec3(a1.xy,h.z); vec3 p3=vec3(a1.zw,h.w);
  vec4 norm=taylorInvSqrt(vec4(dot(p0,p0),dot(p1,p1),dot(p2,p2),dot(p3,p3)));
  p0*=norm.x; p1*=norm.y; p2*=norm.z; p3*=norm.w;
  vec4 m=max(0.6-vec4(dot(x0,x0),dot(x1,x1),dot(x2,x2),dot(x3,x3)),0.0); m=m*m;
  return 42.0*dot(m*m,vec4(dot(p0,x0),dot(p1,x1),dot(p2,x2),dot(p3,x3)));
}
vec3 curl(vec3 p, float t){
  float e=0.28;
  vec3 dx=vec3(e,0.0,0.0), dy=vec3(0.0,e,0.0), dz=vec3(0.0,0.0,e);
  float p_x0=snoise(p-dx+t), p_x1=snoise(p+dx+t);
  float p_y0=snoise(p-dy+vec3(31.4)+t), p_y1=snoise(p+dy+vec3(31.4)+t);
  float p_z0=snoise(p-dz+vec3(-7.7)+t), p_z1=snoise(p+dz+vec3(-7.7)+t);
  float x=p_y1-p_y0-(p_z1-p_z0);
  float y=p_z1-p_z0-(p_x1-p_x0);
  float z=p_x1-p_x0-(p_y1-p_y0);
  return normalize(vec3(x,y,z)+1e-5);
}`;

const VERT = NOISE + `
attribute vec3 aDir;
attribute float aRad, aRand, aLayer, aSize, aSeed;
uniform float uTime, uW[5], uAudio, uFFT[32], uShockT, uShockAmp, uPixel, uBoot;
uniform vec3 uShockDir;
varying vec3 vCol;
varying float vA;

void main(){
  float t = uTime;
  vec3 dir = aDir;
  float wIdle=uW[0], wListen=uW[1], wThink=uW[2], wSpeak=uW[3], wAlert=uW[4];

  // --- concentric ring alignment (listening) -------------------------------
  float bands = 13.0;
  float lat = asin(clamp(dir.y,-1.0,1.0));
  float snapped = (floor(lat/3.14159*bands+0.5))/bands*3.14159;
  vec3 ringDir = normalize(vec3(dir.x, 0.0, dir.z) * cos(snapped) + vec3(0.0,1.0,0.0)*sin(snapped));
  dir = normalize(mix(dir, ringDir, wListen*0.85));

  float r = aRad;

  // --- breathing ------------------------------------------------------------
  float breath = sin(t*1.256 + aSeed*0.4)*0.5+0.5;
  r *= 1.0 + breath*0.035*wIdle + 0.10*wListen;

  // --- layered noise displacement ------------------------------------------
  float turb = 0.55 + 2.4*wThink + 0.5*wAlert;
  float freq = 1.5 + 1.1*wThink;
  float sp = 0.22 + 0.85*wThink + 0.6*wAlert;
  float n1 = snoise(dir*freq + vec3(0.0, t*sp, t*sp*0.6));
  float n2 = snoise(dir*(freq*2.7) + vec3(t*sp*1.7, 0.0, -t*sp));
  float n3 = snoise(dir*(freq*6.1) - vec3(t*sp*2.4));
  float nsum = n1*0.55 + n2*0.28 + n3*0.14;
  float disp = nsum * (0.16 + 0.10*aLayer) * turb;

  // --- curl drift on shell + halo ------------------------------------------
  vec3 c = curl(dir*1.35 + aSeed*0.13, t*0.16);
  float curlAmt = (0.035 + 0.10*step(1.5,aLayer)) * (0.4 + 1.6*wThink + 0.7*wAlert);
  vec3 pos = dir * (r + disp);
  pos += c * curlAmt * (0.6 + aRand);

  // --- halo orbit + inward pull --------------------------------------------
  if(aLayer > 1.5){
    float a = t*(0.06 + aRand*0.09) + aSeed;
    pos = vec3(pos.x*cos(a) - pos.z*sin(a), pos.y, pos.x*sin(a) + pos.z*cos(a));
    float pull = fract(aSeed*0.31 + t*0.035);
    pos *= mix(1.0, 0.58, pull*pull);
  }

  // --- speaking: live FFT deformation --------------------------------------
  float az = atan(dir.z, dir.x);
  float bin = (az + 3.14159) / 6.28318 * 31.0;
  int bi = int(bin);
  float amp = uFFT[bi]/255.0;
  pos += dir * amp * (0.42 + 0.3*abs(dir.y)) * wSpeak;
  pos += dir * uAudio * 0.10 * (wIdle + wListen);

  // --- alert jitter ---------------------------------------------------------
  float jit = snoise(dir*22.0 + t*14.0);
  pos += dir * jit * 0.055 * wAlert;

  // --- shockwave ------------------------------------------------------------
  float ang = acos(clamp(dot(normalize(aDir), uShockDir), -1.0, 1.0));
  float front = uShockT * 3.6;
  float ring = exp(-pow((ang - front)/0.32, 2.0));
  float shock = ring * uShockAmp;
  pos += dir * shock * 0.55;

  // --- boot explosion -------------------------------------------------------
  pos = mix(pos * 0.02, pos, uBoot);

  vec4 mv = modelViewMatrix * vec4(pos, 1.0);
  gl_Position = projectionMatrix * mv;

  float energy = clamp(abs(nsum)*0.62 + amp*wSpeak*1.3 + shock*0.85 + exp(-(aRad-0.30)*2.9)*1.30, 0.0, 1.6);

  vec3 cyan  = vec3(0.00, 0.86, 1.00);
  vec3 blue  = vec3(0.04, 0.42, 1.00);
  vec3 hot   = vec3(0.86, 0.98, 1.00);
  vec3 col = mix(blue, cyan, smoothstep(0.0, 0.55, energy));
  col = mix(col, hot, smoothstep(0.62, 1.25, energy));
  col = mix(col, vec3(0.55,0.24,1.0), wThink*0.85*(0.35+0.65*aRand));
  col = mix(col, vec3(1.0,0.20,0.07), wAlert*0.94);
  col = mix(col, vec3(1.0,0.66,0.20), wAlert*0.18*aRand);
  vCol = col * (0.36 + energy*0.78 + shock*0.45) * (1.0 - wThink*0.44 - wAlert*0.14);

  float a = aLayer < 0.5 ? 0.52 : (aLayer < 1.5 ? 0.44 : 0.28);
  vA = a * uBoot * (0.6 + 0.4*breath);

  float size = aSize * (1.0 + energy*0.6 + shock*1.2) * uPixel;
  gl_PointSize = size * (13.0 / max(0.001, -mv.z));
}`;

const FRAG = `
precision mediump float;
varying vec3 vCol; varying float vA;
void main(){
  vec2 uv = gl_PointCoord - 0.5;
  float d = length(uv);
  if(d > 0.5) discard;
  float a = pow(1.0 - d*2.0, 2.4);
  gl_FragColor = vec4(vCol * a, a * vA);
}`;

const POST = {
  uniforms: {
    tDiffuse: { value: null }, uTime: { value: 0 }, uAmount: { value: 1 },
    uRes: { value: new THREE.Vector2(1, 1) }
  },
  vertexShader: `varying vec2 vUv; void main(){ vUv=uv; gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.0);} `,
  fragmentShader: `
  uniform sampler2D tDiffuse; uniform float uTime, uAmount; uniform vec2 uRes; varying vec2 vUv;
  float hash(vec2 p){ return fract(sin(dot(p,vec2(127.1,311.7)))*43758.5453); }
  void main(){
    vec2 uv = vUv;
    vec2 c = uv - 0.5;
    float r2 = dot(c,c);
    vec2 off = c * (0.0016 + r2*0.010) * uAmount;
    vec4 col;
    col.r = texture2D(tDiffuse, uv + off).r;
    col.g = texture2D(tDiffuse, uv).g;
    col.b = texture2D(tDiffuse, uv - off).b;
    col.a = 1.0;
    float g = hash(uv*uRes + fract(uTime)*137.0);
    col.rgb += (g - 0.5) * 0.045;
    col.rgb *= 1.0 - smoothstep(0.28, 0.95, r2) * 0.55;
    col.rgb *= 0.97 + 0.03*sin(uv.y*uRes.y*1.6);
    gl_FragColor = col;
  }`
};

/* ------------------------------------------------------------ 2D fallback --- */
function fallback2D(canvas, audio) {
  const ctx = canvas.getContext('2d');
  const N = 1400, pts = [];
  for (let i = 0; i < N; i++) {
    const y = 1 - (i / (N - 1)) * 2, rr = Math.sqrt(1 - y * y), th = i * 2.399963;
    pts.push([Math.cos(th) * rr, y, Math.sin(th) * rr]);
  }
  let t = 0, w = 0, weights = [1, 0, 0, 0, 0];
  function loop() {
    const W = canvas.width = canvas.clientWidth, H = canvas.height = canvas.clientHeight;
    t += 0.016; audio.update(0.016);
    ctx.fillStyle = '#03060a'; ctx.fillRect(0, 0, W, H);
    ctx.globalCompositeOperation = 'lighter';
    const R = Math.min(W, H) * 0.26, cx = W / 2, cy = H / 2;
    for (let i = 0; i < N; i++) {
      const p = pts[i];
      const a = t * 0.25, x = p[0] * Math.cos(a) - p[2] * Math.sin(a), z = p[0] * Math.sin(a) + p[2] * Math.cos(a);
      const d = 1 + Math.sin(p[1] * 6 + t * 2) * 0.05 + audio.level * 0.2;
      const s = 2.4 / (2.4 - z * d);
      ctx.fillStyle = `rgba(${60 + z * 120 | 0},${200 + z * 55 | 0},255,${0.25 + s * 0.25})`;
      ctx.fillRect(cx + x * R * d * s, cy + p[1] * R * d * s, 1.6 * s, 1.6 * s);
    }
    ctx.globalCompositeOperation = 'source-over';
    requestAnimationFrame(loop);
  }
  loop();
  return {
    fallback: true, canvas, audio, count: 1400, fps: 60, state: 'idle', setState(s) { }, shock() { }, setPointer() { }, pulse() { }, quality: 1
  };
}

/* ----------------------------------------------------------------- init --- */
function init(canvas, opts = {}) {
  const audio = makeAudio();
  let renderer;
  try {
    renderer = new THREE.WebGLRenderer({ canvas, antialias: false, alpha: false, preserveDrawingBuffer: true, powerPreference: 'high-performance' });
  } catch (e) { return fallback2D(canvas, audio); }
  if (!renderer.getContext()) return fallback2D(canvas, audio);

  renderer.setPixelRatio(Math.min(devicePixelRatio, 1.75));
  renderer.setSize(canvas.clientWidth, canvas.clientHeight, false);
  renderer.setClearColor(new THREE.Color(0x03060a).convertSRGBToLinear(), 1);

  const scene = new THREE.Scene();
  const camera = new THREE.PerspectiveCamera(42, canvas.clientWidth / canvas.clientHeight, 0.1, 100);
  camera.position.set(0, 0, 6.9);

  /* particles */
  const COUNT = opts.count || 132000;
  const aPos = new Float32Array(COUNT * 3), aDir = new Float32Array(COUNT * 3);
  const aRad = new Float32Array(COUNT), aRand = new Float32Array(COUNT);
  const aLayer = new Float32Array(COUNT), aSize = new Float32Array(COUNT), aSeed = new Float32Array(COUNT);
  const GOLD = Math.PI * (3 - Math.sqrt(5));
  const order = [];
  for (let i = 0; i < COUNT; i++) order.push(i);
  for (let i = order.length - 1; i > 0; i--) { const j = (Math.random() * (i + 1)) | 0;[order[i], order[j]] = [order[j], order[i]]; }
  const nCore = Math.floor(COUNT * 0.32), nMid = Math.floor(COUNT * 0.44);
  for (let i = 0; i < COUNT; i++) {
    const k = order[i]; // shuffled so any prefix is a uniform LOD subset
    const layer = k < nCore ? 0 : (k < nCore + nMid ? 1 : 2);
    const li = layer === 0 ? k : (layer === 1 ? k - nCore : k - nCore - nMid);
    const ln = layer === 0 ? nCore : (layer === 1 ? nMid : COUNT - nCore - nMid);
    const y = 1 - (li / Math.max(1, ln - 1)) * 2, rr = Math.sqrt(Math.max(0, 1 - y * y)), th = li * GOLD;
    let dx = Math.cos(th) * rr, dy = y, dz = Math.sin(th) * rr;
    const jitter = layer === 2 ? 0.16 : 0.03;
    dx += (Math.random() - 0.5) * jitter; dy += (Math.random() - 0.5) * jitter; dz += (Math.random() - 0.5) * jitter;
    const len = Math.hypot(dx, dy, dz) || 1;
    aDir[i * 3] = dx / len; aDir[i * 3 + 1] = dy / len; aDir[i * 3 + 2] = dz / len;
    aPos[i * 3] = dx / len; aPos[i * 3 + 1] = dy / len; aPos[i * 3 + 2] = dz / len;
    const rnd = Math.random();
    aRand[i] = rnd; aSeed[i] = Math.random() * 100; aLayer[i] = layer;
    aRad[i] = layer === 0 ? 0.34 + Math.pow(rnd, 0.75) * 0.52
      : layer === 1 ? 0.92 + rnd * 0.10
        : 1.12 + Math.pow(rnd, 1.9) * 0.95;
    aSize[i] = layer === 0 ? 1.0 + rnd * 1.0 : layer === 1 ? 0.8 + rnd * 0.9 : 0.6 + rnd * 1.5;
  }
  const geo = new THREE.BufferGeometry();
  geo.setAttribute('position', new THREE.BufferAttribute(aPos, 3));
  geo.setAttribute('aDir', new THREE.BufferAttribute(aDir, 3));
  geo.setAttribute('aRad', new THREE.BufferAttribute(aRad, 1));
  geo.setAttribute('aRand', new THREE.BufferAttribute(aRand, 1));
  geo.setAttribute('aLayer', new THREE.BufferAttribute(aLayer, 1));
  geo.setAttribute('aSize', new THREE.BufferAttribute(aSize, 1));
  geo.setAttribute('aSeed', new THREE.BufferAttribute(aSeed, 1));
  geo.boundingSphere = new THREE.Sphere(new THREE.Vector3(), 4);

  const uniforms = {
    uTime: { value: 0 },
    uW: { value: [1, 0, 0, 0, 0] },
    uAudio: { value: 0 },
    uFFT: { value: new Array(32).fill(0) },
    uShockT: { value: 99 },
    uShockAmp: { value: 0 },
    uShockDir: { value: new THREE.Vector3(0, 0, 1) },
    uPixel: { value: 1 },
    uBoot: { value: 0 }
  };
  const mat = new THREE.ShaderMaterial({
    uniforms, vertexShader: VERT, fragmentShader: FRAG,
    blending: THREE.AdditiveBlending, depthWrite: false, depthTest: false, transparent: true
  });
  const points = new THREE.Points(geo, mat);
  scene.add(points);

  /* ambient: wireframe globe + orbital rings + dust */
  const globe = new THREE.LineSegments(
    new THREE.WireframeGeometry(new THREE.SphereGeometry(1.72, 26, 16)),
    new THREE.LineBasicMaterial({ color: 0x0a84ff, transparent: true, opacity: 0.055, blending: THREE.AdditiveBlending, depthWrite: false })
  );
  globe.position.x = 0.15; scene.add(globe);
  const rings = new THREE.Group();
  [[2.15, 0.62, 0x00e5ff, 0.10], [2.62, -0.38, 0x0a84ff, 0.07], [3.05, 1.15, 0x00e5ff, 0.05]].forEach(([r, tilt, col, op]) => {
    const pts = [];
    for (let i = 0; i <= 220; i++) { const a = i / 220 * Math.PI * 2; pts.push(new THREE.Vector3(Math.cos(a) * r, 0, Math.sin(a) * r)); }
    const l = new THREE.Line(new THREE.BufferGeometry().setFromPoints(pts),
      new THREE.LineBasicMaterial({ color: col, transparent: true, opacity: op, blending: THREE.AdditiveBlending, depthWrite: false }));
    l.rotation.x = tilt; l.rotation.z = tilt * 0.4; rings.add(l);
  });
  scene.add(rings);

  const DUST = 2600, dp = new Float32Array(DUST * 3), ds = new Float32Array(DUST);
  for (let i = 0; i < DUST; i++) {
    dp[i * 3] = (Math.random() - 0.5) * 26; dp[i * 3 + 1] = (Math.random() - 0.5) * 16; dp[i * 3 + 2] = -Math.random() * 24 - 2;
    ds[i] = Math.random() * 2 + 0.6;
  }
  const dgeo = new THREE.BufferGeometry();
  dgeo.setAttribute('position', new THREE.BufferAttribute(dp, 3));
  dgeo.setAttribute('aScale', new THREE.BufferAttribute(ds, 1));
  const dust = new THREE.Points(dgeo, new THREE.ShaderMaterial({
    uniforms: { uTime: { value: 0 } },
    vertexShader: `attribute float aScale; uniform float uTime; varying float vA;
      void main(){ vec3 p=position; p.x += sin(uTime*0.06 + position.y*0.4)*1.4; p.y += cos(uTime*0.05 + position.x*0.3)*0.9;
      vec4 mv=modelViewMatrix*vec4(p,1.0); gl_Position=projectionMatrix*mv; vA=0.18+0.3*aScale*0.25;
      gl_PointSize=aScale*(26.0/max(0.001,-mv.z)); }`,
    fragmentShader: `precision mediump float; varying float vA; void main(){ vec2 u=gl_PointCoord-0.5; float d=length(u);
      if(d>0.5) discard; gl_FragColor=vec4(vec3(0.35,0.68,0.9)*(1.0-d*2.0), (1.0-d*2.0)*vA); }`,
    transparent: true, depthWrite: false, blending: THREE.AdditiveBlending
  }));
  scene.add(dust);

  /* post */
  const composer = new EffectComposer(renderer);
  composer.setPixelRatio(Math.min(devicePixelRatio, 1.75));
  composer.setSize(canvas.clientWidth, canvas.clientHeight);
  composer.addPass(new RenderPass(scene, camera));
  const bloom = new UnrealBloomPass(new THREE.Vector2(canvas.clientWidth, canvas.clientHeight), 1.25, 0.62, 0.32);
  composer.addPass(bloom);
  composer.addPass(new OutputPass());
  const post = new ShaderPass(POST);
  post.renderToScreen = true;
  composer.addPass(post);

  /* state */
  const weights = [1, 0, 0, 0, 0], target = [1, 0, 0, 0, 0];
  let stateName = 'idle';
  const pointer = { x: 0, y: 0, tx: 0, ty: 0 };
  let shockT = 99, shockAmp = 0;
  let quality = 1, fpsAcc = 0, fpsFrames = 0, qualityLocked = false;
  let bootStart = 0, booted = false;

  function resize() {
    const w = canvas.clientWidth, h = canvas.clientHeight;
    if (!w || !h) return;
    if (canvas.width === Math.floor(w * renderer.getPixelRatio()) && camera.aspect === w / h) return;
    camera.aspect = w / h; camera.updateProjectionMatrix();
    renderer.setSize(w, h, false); composer.setSize(w, h);
    post.uniforms.uRes.value.set(w, h);
    bloom.setSize(w, h);
  }
  addEventListener('resize', resize);

  const clock = new THREE.Clock();
  function frame() {
    requestAnimationFrame(frame);
    const dt = Math.min(0.05, clock.getDelta());
    const t = clock.elapsedTime;
    resize();
    audio.update(dt);

    for (let i = 0; i < 5; i++) weights[i] += (target[i] - weights[i]) * Math.min(1, dt * 3.4);
    uniforms.uW.value = weights;
    uniforms.uTime.value = t;
    uniforms.uAudio.value = audio.level;
    for (let i = 0; i < 32; i++) uniforms.uFFT.value[i] = audio.fft[i] * (0.35 + 0.65 * weights[3]);

    if (shockT < 2.2) { shockT += dt; shockAmp *= Math.pow(0.22, dt); }
    uniforms.uShockT.value = shockT; uniforms.uShockAmp.value = shockAmp;

    if (!booted) { bootStart += dt; uniforms.uBoot.value = easeOutExpo(Math.min(1, bootStart / 1.6)); if (bootStart > 1.7) booted = true; }
    else uniforms.uBoot.value = 1;

    pointer.x += (pointer.tx - pointer.x) * Math.min(1, dt * 2.2);
    pointer.y += (pointer.ty - pointer.y) * Math.min(1, dt * 2.2);
    camera.position.x = pointer.x * 0.55;
    camera.position.y = -pointer.y * 0.35;
    camera.position.z = 6.9 - weights[1] * 0.4 + weights[4] * 0.15;
    camera.lookAt(0, 0, 0);

    points.rotation.y += dt * (0.055 + weights[2] * 0.22 + weights[4] * 0.3);
    points.rotation.x = Math.sin(t * 0.13) * 0.09;
    globe.rotation.y -= dt * 0.035; globe.rotation.x = Math.sin(t * 0.08) * 0.2;
    rings.rotation.y += dt * 0.045; rings.rotation.z = Math.sin(t * 0.07) * 0.12;
    dust.material.uniforms.uTime.value = t;

    bloom.strength = api.bloomBase + weights[1] * 0.25 + weights[4] * 0.3 + audio.level * 0.18;
    post.uniforms.uTime.value = t;
    post.uniforms.uAmount.value = 1 + weights[2] * 2.2 + weights[4] * 3.4;

    composer.render();

    // adaptive particle cap
    fpsAcc += dt; fpsFrames++;
    if (fpsAcc > 2 && !qualityLocked) {
      const fps = fpsFrames / fpsAcc;
      if (fps < 32 && quality > 0.35) quality = Math.max(0.35, quality - 0.3);
      else if (fps < 46 && quality > 0.5) quality = Math.max(0.5, quality - 0.18);
      else if (fps > 57 && quality < 1) quality = Math.min(1, quality + 0.1);
      else if (fps > 50) qualityLocked = true;
      geo.setDrawRange(0, Math.floor(COUNT * quality));
      uniforms.uPixel.value = 1 / Math.sqrt(quality);
      api.fps = fps; fpsAcc = 0; fpsFrames = 0;
    } else if (fpsAcc > 1) { api.fps = fpsFrames / fpsAcc; fpsAcc = 0; fpsFrames = 0; }
  }
  function easeOutExpo(x) { return x >= 1 ? 1 : 1 - Math.pow(2, -10 * x); }

  const api = {
    fallback: false, audio, canvas, renderer, composer, uniforms, scene, camera, count: COUNT, fps: 60, bloomBase: opts.bloom || 1.05,
    get quality() { return quality; },
    get state() { return stateName; },
    setState(name) {
      const i = STATES.indexOf(name); if (i < 0) return;
      stateName = name;
      for (let k = 0; k < 5; k++) target[k] = k === i ? 1 : 0;
    },
    pulse(name, ms = 2200) {
      const prev = stateName === name ? 'idle' : stateName;
      api.setState(name);
      clearTimeout(api._pt);
      api._pt = setTimeout(() => api.setState(prev === 'alert' ? 'idle' : prev), ms);
    },
    shock(nx = 0, ny = 0) {
      const v = new THREE.Vector3(nx, ny, 0.85).normalize();
      uniforms.uShockDir.value.copy(v);
      shockT = 0; shockAmp = 1;
    },
    setPointer(nx, ny) { pointer.tx = nx; pointer.ty = ny; }
  };
  frame();
  return api;
}

window.JARVIS_ENGINE = { init, STATES };
window.dispatchEvent(new Event('jarvis-engine-ready'));
